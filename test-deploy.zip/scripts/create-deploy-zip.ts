#!/usr/bin/env npx tsx
/**
 * create-deploy-zip.ts - Create a deployment zip for hot reload
 * 
 * Creates a zip containing all source files needed for a hot reload deployment.
 * Used by deploy.js for quick deploys and can be run standalone for testing.
 * 
 * Usage: npx tsx scripts/create-deploy-zip.ts [outputPath]
 * 
 * If outputPath is not provided, creates hot-reload-deploy.zip in the temp directory
 * and prints the path to stdout.
 */

import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import type { Archiver } from "archiver";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const APP_ROOT = path.resolve(__dirname, "..");

/**
 * Create a deployment zip containing source files for hot reload.
 * Returns the path to the created zip file.
 */
export async function createDeploymentZip(outputPath?: string): Promise<string> {
  // Dynamic import for archiver (ESM/CJS compatibility)
  const archiverModule = await import("archiver");
  const archiver = archiverModule.default as (format: string, options?: object) => Archiver;
  
  const zipPath = outputPath || path.join(os.tmpdir(), "hot-reload-deploy.zip");
  const output = fs.createWriteStream(zipPath);
  const archive = archiver("zip", { zlib: { level: 9 } });
  
  return new Promise((resolve, reject) => {
    output.on("close", () => resolve(zipPath));
    archive.on("error", reject);
    
    archive.pipe(output);
    
    // Whitelist approach: only include *.ts, *.svg, package*.json, tsconfig*.json, 
    // index.html, vite.config.ts, and prompt-template.md
    const allowedExtensions = [".ts", ".svg"];
    const allowedFiles = ["package.json", "package-lock.json", "tsconfig.json", "index.html"];
    
    // Filter returns false to skip, or entry data to include
    const fileFilter = (entry: { name: string }) => {
      const ext = path.extname(entry.name);
      const base = path.basename(entry.name);
      if (allowedExtensions.includes(ext) || allowedFiles.includes(base)) {
        return entry; // include with original entry data
      }
      return false; // skip
    };
    
    // Source directories (filtered to whitelist)
    archive.directory(path.join(APP_ROOT, "server", "src"), "server/src", fileFilter);
    archive.directory(path.join(APP_ROOT, "client", "src"), "client/src", fileFilter);
    archive.directory(path.join(APP_ROOT, "scripts"), "scripts", fileFilter);
    
    // Root package files
    archive.file(path.join(APP_ROOT, "package.json"), { name: "package.json" });
    archive.file(path.join(APP_ROOT, "package-lock.json"), { name: "package-lock.json" });
    archive.file(path.join(APP_ROOT, "tsconfig.base.json"), { name: "tsconfig.base.json" });
    
    // Server package/config
    archive.file(path.join(APP_ROOT, "server", "package.json"), { name: "server/package.json" });
    archive.file(path.join(APP_ROOT, "server", "tsconfig.json"), { name: "server/tsconfig.json" });
    
    // Client package/config/build
    archive.file(path.join(APP_ROOT, "client", "package.json"), { name: "client/package.json" });
    archive.file(path.join(APP_ROOT, "client", "tsconfig.json"), { name: "client/tsconfig.json" });
    archive.file(path.join(APP_ROOT, "client", "index.html"), { name: "client/index.html" });
    archive.file(path.join(APP_ROOT, "client", "vite.config.ts"), { name: "client/vite.config.ts" });
    
    // Prompt template (used by chatbot)
    archive.file(path.join(APP_ROOT, "dataConfig", "prompt-template.md"), { name: "dataConfig/prompt-template.md" });
    
    archive.finalize();
  });
}

// Run standalone if executed directly
// Check if this file is being run directly (not imported)
const runningDirectly = process.argv[1]?.includes("create-deploy-zip");
if (runningDirectly) {
  const outputPath = process.argv[2];
  
  createDeploymentZip(outputPath)
    .then(zipPath => {
      const stats = fs.statSync(zipPath);
      console.log(zipPath);
      console.error(`Created ${(stats.size / 1024).toFixed(1)} KB`);
    })
    .catch(err => {
      console.error("Failed to create zip:", err);
      process.exit(1);
    });
}
