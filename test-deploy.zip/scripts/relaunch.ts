#!/usr/bin/env npx tsx
/**
 * relaunch.ts - Hot reload helper script
 * 
 * This script is spawned by the server when it receives a hot-reload request.
 * It runs as a detached process and:
 * 1. Waits for the server to shut down (PID file disappears)
 * 2. Extracts the new code from the zip
 * 3. Runs npm install if package.json changed
 * 4. Rebuilds the TypeScript
 * 5. Restarts the server
 * 
 * Usage: npx tsx scripts/relaunch.ts <zipPath> <appRoot>
 */

import fs from "node:fs";
import path from "node:path";
import { execSync, spawn } from "node:child_process";
import { createReadStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import { createWriteStream } from "node:fs";

// We'll use yauzl for zip extraction - it's a dependency-free unzip library
// But since we want to avoid adding deps, let's use the built-in zlib + manual zip parsing
// Actually, let's use a simpler approach: extract using Node's built-in capabilities

const args = process.argv.slice(2);
const testMode = args.includes("--test");
const filteredArgs = args.filter(a => a !== "--test");
const zipPath = filteredArgs[0];
const appRoot = filteredArgs[1];

if (!zipPath || !appRoot) {
  console.error("Usage: npx tsx scripts/relaunch.ts <zipPath> <appRoot> [--test]");
  process.exit(1);
}

const PID_FILE = path.join(appRoot, "server.pid");
const EXTRACT_DIR = path.join("/tmp", "hot-reload-extract");
const LOG_FILE = path.join(appRoot, "dataDiagnostics", "relaunch.log");

function log(message: string) {
  const timestamp = new Date().toISOString();
  const line = `[${timestamp}] ${message}`;
  console.log(line);
  try {
    fs.appendFileSync(LOG_FILE, line + "\n");
  } catch {
    // Ignore log write errors
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Wait for the server to shut down by polling for PID file removal.
 * Also checks if the PID is still alive as a fallback.
 */
async function waitForServerShutdown(maxWaitMs: number = 30000): Promise<boolean> {
  const startTime = Date.now();
  const pollInterval = 500;
  
  log("Waiting for server to shut down...");
  
  while (Date.now() - startTime < maxWaitMs) {
    // Check if PID file exists
    if (!fs.existsSync(PID_FILE)) {
      log("PID file removed - server has shut down");
      return true;
    }
    
    // Check if the process is still alive
    try {
      const pid = parseInt(fs.readFileSync(PID_FILE, "utf-8").trim(), 10);
      process.kill(pid, 0); // Signal 0 = just check if process exists
      // Process still alive, keep waiting
    } catch {
      // Process doesn't exist, PID file is stale
      log("Server process no longer running");
      try {
        fs.unlinkSync(PID_FILE);
      } catch { /* ignore */ }
      return true;
    }
    
    await sleep(pollInterval);
  }
  
  log("Timeout waiting for server shutdown");
  return false;
}

/**
 * Extract zip file using built-in zlib.
 * This is a simple implementation that handles basic zip files.
 */
async function extractZip(zipPath: string, destDir: string): Promise<void> {
  // Use unzip command if available, otherwise fall back to manual extraction
  // Since we're on Linux (App Runner), unzip should be available
  
  // Clean and create destination directory
  if (fs.existsSync(destDir)) {
    fs.rmSync(destDir, { recursive: true });
  }
  fs.mkdirSync(destDir, { recursive: true });
  
  try {
    // Try using system unzip first (more reliable for complex zips)
    execSync(`unzip -o "${zipPath}" -d "${destDir}"`, { stdio: "pipe" });
    log("Extracted using system unzip");
  } catch {
    // Fall back to Node.js extraction
    log("System unzip failed, using Node.js extraction");
    await extractZipNode(zipPath, destDir);
  }
}

/**
 * Pure Node.js zip extraction using zlib.
 * Handles basic zip files without external dependencies.
 */
async function extractZipNode(zipPath: string, destDir: string): Promise<void> {
  const { promisify } = await import("node:util");
  const zlib = await import("node:zlib");
  
  const zipBuffer = fs.readFileSync(zipPath);
  let offset = 0;
  
  while (offset < zipBuffer.length - 4) {
    // Look for local file header signature (PK\x03\x04)
    if (zipBuffer[offset] !== 0x50 || zipBuffer[offset + 1] !== 0x4B) {
      break;
    }
    if (zipBuffer[offset + 2] !== 0x03 || zipBuffer[offset + 3] !== 0x04) {
      // Not a local file header, might be central directory
      break;
    }
    
    // Parse local file header
    const compressionMethod = zipBuffer.readUInt16LE(offset + 8);
    const compressedSize = zipBuffer.readUInt32LE(offset + 18);
    const uncompressedSize = zipBuffer.readUInt32LE(offset + 22);
    const fileNameLength = zipBuffer.readUInt16LE(offset + 26);
    const extraFieldLength = zipBuffer.readUInt16LE(offset + 28);
    
    const fileNameStart = offset + 30;
    const fileName = zipBuffer.toString("utf-8", fileNameStart, fileNameStart + fileNameLength);
    const dataStart = fileNameStart + fileNameLength + extraFieldLength;
    
    const destPath = path.join(destDir, fileName);
    
    // Create directories
    if (fileName.endsWith("/")) {
      fs.mkdirSync(destPath, { recursive: true });
    } else {
      // Ensure parent directory exists
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      
      // Extract file
      const compressedData = zipBuffer.subarray(dataStart, dataStart + compressedSize);
      
      let fileData: Buffer;
      if (compressionMethod === 0) {
        // Stored (no compression)
        fileData = compressedData;
      } else if (compressionMethod === 8) {
        // Deflate
        fileData = zlib.inflateRawSync(compressedData);
      } else {
        throw new Error(`Unsupported compression method: ${compressionMethod}`);
      }
      
      fs.writeFileSync(destPath, fileData);
    }
    
    offset = dataStart + compressedSize;
  }
  
  log("Extracted using Node.js zlib");
}

/**
 * List files in a zip without extracting (for test mode).
 */
function listZipContents(zipPath: string): string[] {
  const files: string[] = [];
  const zipBuffer = fs.readFileSync(zipPath);
  let offset = 0;
  
  while (offset < zipBuffer.length - 4) {
    if (zipBuffer[offset] !== 0x50 || zipBuffer[offset + 1] !== 0x4B) break;
    if (zipBuffer[offset + 2] !== 0x03 || zipBuffer[offset + 3] !== 0x04) break;
    
    const compressedSize = zipBuffer.readUInt32LE(offset + 18);
    const fileNameLength = zipBuffer.readUInt16LE(offset + 26);
    const extraFieldLength = zipBuffer.readUInt16LE(offset + 28);
    
    const fileNameStart = offset + 30;
    const fileName = zipBuffer.toString("utf-8", fileNameStart, fileNameStart + fileNameLength);
    const dataStart = fileNameStart + fileNameLength + extraFieldLength;
    
    if (!fileName.endsWith("/")) {
      files.push(fileName);
    }
    
    offset = dataStart + compressedSize;
  }
  
  return files;
}

/**
 * Copy extracted files to the app directory.
 */
function copyFiles(srcDir: string, destDir: string): number {
  let count = 0;
  
  function copyRecursive(src: string, dest: string) {
    const entries = fs.readdirSync(src, { withFileTypes: true });
    
    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      
      if (entry.isDirectory()) {
        fs.mkdirSync(destPath, { recursive: true });
        copyRecursive(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
        count++;
      }
    }
  }
  
  copyRecursive(srcDir, destDir);
  return count;
}

/**
 * Check if package.json changed (compare with existing).
 */
function packageJsonChanged(extractDir: string, appRoot: string): boolean {
  const newPkgPath = path.join(extractDir, "package.json");
  const oldPkgPath = path.join(appRoot, "package.json");
  
  if (!fs.existsSync(newPkgPath)) {
    return false;
  }
  if (!fs.existsSync(oldPkgPath)) {
    return true;
  }
  
  const newPkg = fs.readFileSync(newPkgPath, "utf-8");
  const oldPkg = fs.readFileSync(oldPkgPath, "utf-8");
  
  return newPkg !== oldPkg;
}

async function main() {
  log("=".repeat(60));
  log(testMode ? "RELAUNCH SCRIPT TEST MODE" : "RELAUNCH SCRIPT STARTED");
  log(`Zip path: ${zipPath}`);
  log(`App root: ${appRoot}`);
  log("=".repeat(60));
  
  // TEST MODE: Just validate zip and list contents, don't actually do anything
  if (testMode) {
    if (!fs.existsSync(zipPath)) {
      log("[TEST] ERROR: Zip file not found!");
      process.exit(1);
    }
    
    const stats = fs.statSync(zipPath);
    log(`[TEST] Zip file exists: ${stats.size} bytes`);
    
    const files = listZipContents(zipPath);
    log(`[TEST] Zip contains ${files.length} files:`);
    for (const file of files) {
      log(`[TEST]   ${file}`);
    }
    
    // Clean up test zip
    fs.unlinkSync(zipPath);
    log("[TEST] Cleaned up zip file");
    log("[TEST] Test complete - would have deployed these files");
    process.exit(0);
  }
  
  try {
    // Step 1: Wait for server to shut down
    const shutdown = await waitForServerShutdown(30000);
    if (!shutdown) {
      log("ERROR: Server did not shut down in time");
      process.exit(1);
    }
    
    // Step 2: Extract zip
    log("Extracting zip file...");
    await extractZip(zipPath, EXTRACT_DIR);
    
    // Step 3: Check if package.json changed
    const needsInstall = packageJsonChanged(EXTRACT_DIR, appRoot);
    log(`package.json changed: ${needsInstall}`);
    
    // Step 4: Copy files to app directory
    log("Copying files to app directory...");
    const filesCopied = copyFiles(EXTRACT_DIR, appRoot);
    log(`Copied ${filesCopied} files`);
    
    // Step 5: Run npm install if needed
    if (needsInstall) {
      log("Running npm install...");
      execSync("npm install", { cwd: appRoot, stdio: "inherit" });
    }
    
    // Step 6: Build TypeScript
    log("Building TypeScript...");
    execSync("npm run build", { cwd: appRoot, stdio: "inherit" });
    
    // Step 7: Start the server
    log("Starting server...");
    const serverProcess = spawn("npm", ["start"], {
      cwd: appRoot,
      detached: true,
      stdio: "ignore"
    });
    serverProcess.unref();
    
    log(`Server started (PID ${serverProcess.pid})`);
    log("=".repeat(60));
    log("RELAUNCH COMPLETE");
    log("=".repeat(60));
    
    // Clean up
    fs.rmSync(EXTRACT_DIR, { recursive: true, force: true });
    fs.unlinkSync(zipPath);
    
  } catch (error) {
    log(`FATAL ERROR: ${error}`);
    process.exit(1);
  }
}

main();
