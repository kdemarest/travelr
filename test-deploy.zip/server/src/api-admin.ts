/**
 * Admin API endpoints for file persistence and system management.
 * 
 * GET /admin/files - Download all persistent files as JSON
 * POST /admin/files - Upload and restore persistent files
 * POST /admin/maintenance - Enable/disable maintenance mode
 * POST /admin/persist - Upload local files to S3
 * POST /admin/hot-reload - Receive zip, trigger server restart with new code
 * 
 * Protected by isAdmin check on authenticated user.
 */

import { Router, Request, Response } from "express";
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { uploadToS3, isS3Enabled } from "./s3-sync.js";
import { isHotReloadAllowed } from "./config.js";
import { removePidFile } from "./pid-file.js";
import type { AuthenticatedRequest } from "./index.js";

const router = Router();

const DATA_USERS_DIR = process.env.DATA_USERS_DIR || path.join(process.cwd(), "dataUsers");
const DATA_TRIPS_DIR = process.env.DATA_TRIPS_DIR || path.join(process.cwd(), "dataTrips");

// Maintenance mode - when true, server rejects data-modifying requests
let maintenanceMode = false;

export function isMaintenanceMode(): boolean {
  return maintenanceMode;
}

export function getMaintenanceMessage(): string {
  return "Please wait while the server is being updated. This usually takes about a minute.";
}

interface FileEntry {
  name: string;
  content: string;
}

interface FilesPayload {
  timestamp: string;
  files: FileEntry[];
}

/**
 * Middleware to check admin access.
 * User is already authenticated by requireAuth middleware in index.ts.
 */
function requireAdmin(req: Request, res: Response, next: () => void) {
  const user = (req as AuthenticatedRequest).user;
  
  if (!user.isAdmin) {
    return res.status(403).json({ ok: false, error: "Admin access required" });
  }

  next();
}

/**
 * Read all files from a directory (non-recursive, files only).
 */
function readDirFiles(dir: string, prefix: string = ""): FileEntry[] {
  const files: FileEntry[] = [];
  
  if (!fs.existsSync(dir)) {
    return files;
  }

  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isFile()) {
      const filePath = path.join(dir, entry.name);
      const content = fs.readFileSync(filePath, "utf-8");
      files.push({
        name: prefix ? `${prefix}/${entry.name}` : entry.name,
        content
      });
    } else if (entry.isDirectory()) {
      // Recurse into subdirectories
      const subPrefix = prefix ? `${prefix}/${entry.name}` : entry.name;
      files.push(...readDirFiles(path.join(dir, entry.name), subPrefix));
    }
  }

  return files;
}

/**
 * GET /admin/files - Download all persistent files
 */
router.get("/files", requireAdmin, (_req: Request, res: Response) => {
  try {
    const files: FileEntry[] = [];

    // Read dataUsers files
    const userFiles = readDirFiles(DATA_USERS_DIR);
    for (const f of userFiles) {
      files.push({ name: `dataUsers/${f.name}`, content: f.content });
    }

    // Read dataTrips files
    const tripFiles = readDirFiles(DATA_TRIPS_DIR);
    for (const f of tripFiles) {
      files.push({ name: `dataTrips/${f.name}`, content: f.content });
    }

    const payload: FilesPayload = {
      timestamp: new Date().toISOString(),
      files
    };

    res.json(payload);
  } catch (error) {
    console.error("Failed to read files:", error);
    res.status(500).json({ error: "Failed to read files" });
  }
});

/**
 * POST /admin/files - Upload and restore persistent files
 */
router.post("/files", requireAdmin, (req: Request, res: Response) => {
  try {
    const payload = req.body as FilesPayload;
    
    if (!payload.files || !Array.isArray(payload.files)) {
      return res.status(400).json({ error: "Invalid payload: expected { files: [...] }" });
    }

    let restored = 0;
    for (const file of payload.files) {
      if (!file.name || typeof file.content !== "string") {
        continue;
      }

      // Determine target directory based on prefix
      // WARNING: users.json contains password hashes - never allow overwriting via this endpoint
      if (file.name === "dataUsers/users.json") {
        console.warn("Skipping users.json - cannot overwrite password file via API");
        continue;
      }

      let targetPath: string;
      if (file.name.startsWith("dataUsers/")) {
        targetPath = path.join(DATA_USERS_DIR, file.name.replace("dataUsers/", ""));
      } else if (file.name.startsWith("dataTrips/")) {
        targetPath = path.join(DATA_TRIPS_DIR, file.name.replace("dataTrips/", ""));
      } else {
        // Skip unknown prefixes for safety
        console.warn(`Skipping unknown file prefix: ${file.name}`);
        continue;
      }

      // Ensure directory exists
      const dir = path.dirname(targetPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      // Write file
      fs.writeFileSync(targetPath, file.content, "utf-8");
      restored++;
    }

    res.json({ ok: true, restored, total: payload.files.length });
  } catch (error) {
    console.error("Failed to restore files:", error);
    res.status(500).json({ ok: false, error: "Failed to restore files" });
  }
});

/**
 * POST /admin/maintenance - Enable or disable maintenance mode
 * 
 * Body: { enabled: true/false }
 * 
 * When enabled, the server will reject data-modifying requests with a friendly message.
 * Call this BEFORE /admin/persist during deploy.
 */
router.post("/maintenance", requireAdmin, (req: Request, res: Response) => {
  const { enabled } = req.body as { enabled?: boolean };
  
  if (typeof enabled !== "boolean") {
    return res.status(400).json({ ok: false, error: "Expected { enabled: true/false }" });
  }
  
  maintenanceMode = enabled;
  console.log(`[Admin] Maintenance mode ${enabled ? "ENABLED" : "DISABLED"}`);
  
  res.json({ 
    ok: true, 
    maintenanceMode: enabled,
    message: enabled ? getMaintenanceMessage() : "Server is accepting requests normally"
  });
});

/**
 * POST /admin/persist - Upload local files to S3
 * 
 * Called by deploy script before rebuilding to ensure data is saved.
 */
router.post("/persist", requireAdmin, async (_req: Request, res: Response) => {
  try {
    if (!isS3Enabled()) {
      return res.status(400).json({ 
        ok: false, 
        error: "S3 not configured - set TRAVELR_S3_BUCKET environment variable" 
      });
    }
    
    const filesUploaded = await uploadToS3();
    
    res.json({ 
      ok: true, 
      filesUploaded,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Failed to persist to S3:", error);
    res.status(500).json({ ok: false, error: "Failed to persist to S3" });
  }
});

/**
 * POST /admin/hot-reload - Receive deployment zip and restart server
 * 
 * Requires:
 * - isAdmin user
 * - hotReloadAllowed: true in config
 * 
 * Body: raw zip file (application/zip or application/octet-stream)
 * 
 * Flow:
 * 1. Save zip to /tmp/hot-reload.zip
 * 2. Spawn relaunch.ts as detached process
 * 3. Respond with success
 * 4. Gracefully shutdown server
 * 5. relaunch.ts waits for PID file to disappear, then extracts and restarts
 */
router.post("/hot-reload", requireAdmin, async (req: Request, res: Response) => {
  const testMode = req.query.test === "true";
  
  // Security check: must be explicitly enabled in config (unless test mode)
  if (!testMode && !isHotReloadAllowed()) {
    console.error("[HotReload] REJECTED - hotReloadAllowed is not true in config");
    return res.status(403).json({ 
      ok: false, 
      error: "Hot reload is not enabled on this server. Set hotReloadAllowed: true in config." 
    });
  }
  
  try {
    // Get raw body as buffer
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
      chunks.push(chunk as Buffer);
    }
    const zipBuffer = Buffer.concat(chunks);
    
    if (zipBuffer.length === 0) {
      return res.status(400).json({ ok: false, error: "No zip data received" });
    }
    
    // Validate it looks like a zip (starts with PK)
    if (zipBuffer[0] !== 0x50 || zipBuffer[1] !== 0x4B) {
      return res.status(400).json({ ok: false, error: "Invalid zip file (bad magic bytes)" });
    }
    
    console.log(`[HotReload] Received ${zipBuffer.length} bytes`);
    
    // Save to temp location
    const zipPath = "/tmp/hot-reload.zip";
    fs.writeFileSync(zipPath, zipBuffer);
    console.log(`[HotReload] Saved zip to ${zipPath}`);
    
    // Spawn relaunch.ts as detached process
    // It will wait for the server to shut down, then extract and restart
    const relaunchScript = path.resolve(__dirname, "../../scripts/relaunch.ts");
    const appRoot = path.resolve(__dirname, "../..");
    
    console.log(`[HotReload] Spawning relaunch script: ${relaunchScript}${testMode ? " (TEST MODE)" : ""}`);
    
    const relaunchArgs = ["tsx", relaunchScript, zipPath, appRoot];
    if (testMode) {
      relaunchArgs.push("--test");
    }
    
    const child = spawn("npx", relaunchArgs, {
      detached: true,
      stdio: testMode ? "inherit" : "ignore",
      cwd: appRoot
    });
    child.unref();
    
    console.log(`[HotReload] Relaunch process spawned (PID ${child.pid})`);
    
    // Respond before shutting down
    res.json({ 
      ok: true, 
      message: testMode 
        ? "Hot reload TEST - check server logs for file list. Server NOT restarted."
        : "Hot reload initiated. Server will restart shortly.",
      zipSize: zipBuffer.length,
      relaunchPid: child.pid,
      testMode
    });
    
    // In test mode, don't shutdown - just let the test script run and exit
    if (!testMode) {
      // Give response time to send, then gracefully shutdown
      setTimeout(() => {
        console.log("[HotReload] Initiating graceful shutdown...");
        removePidFile();
        process.exit(0);
      }, 500);
    }
    
  } catch (error) {
    console.error("[HotReload] Failed:", error);
    res.status(500).json({ ok: false, error: `Hot reload failed: ${error}` });
  }
});

export default router;
