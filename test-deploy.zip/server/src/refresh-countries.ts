import fs from "fs-extra";
import { getIsoCountryCatalogPath, reloadIsoCountryCatalog, type IsoCodeRecord } from "./iso-codes.js";

const SOURCE_URL =
  "https://raw.githubusercontent.com/lukes/ISO-3166-Countries-with-Regional-Codes/master/all/all.json";

interface SourceCountryRecord {
  name?: string;
  [key: string]: string | undefined;
}

interface NormalizedCountryRecord {
  countryName: string;
  countryAlpha2: string;
  aliases: string[];
}

export interface RefreshCountriesSummary {
  downloaded: number;
  normalized: number;
  added: number;
  updated: number;
  skipped: number;
  catalogPath: string;
}

export async function refreshCountryCatalog(): Promise<RefreshCountriesSummary> {
  const response = await fetch(SOURCE_URL, {
    headers: {
      "User-Agent": "TravelrCountryRefresh/1.0",
      Accept: "application/json"
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to download country data (${response.status} ${response.statusText}).`);
  }

  const payload = (await response.json()) as SourceCountryRecord[];
  const normalized = payload
    .map((record) => normalizeSourceRecord(record))
    .filter((record): record is NormalizedCountryRecord => Boolean(record));

  const catalogPath = getIsoCountryCatalogPath();
  const existingRecords = (await readExistingCatalog(catalogPath)) as IsoCodeRecord[];
  const mergedMap = new Map<string, IsoCodeRecord>();
  for (const record of existingRecords) {
    if (record.countryAlpha2) {
      mergedMap.set(record.countryAlpha2.toUpperCase(), { ...record });
    }
  }

  let added = 0;
  let updated = 0;

  for (const record of normalized) {
    const key = record.countryAlpha2;
    const current = mergedMap.get(key);
    if (!current) {
      mergedMap.set(key, {
        countryName: record.countryName,
        countryAlpha2: key,
        currencyAlpha3: "",
        aliases: record.aliases.length ? record.aliases : undefined
      });
      added += 1;
      continue;
    }

    const aliasSet = new Map<string, string>();
    if (current.aliases) {
      for (const alias of current.aliases) {
        aliasSet.set(alias.toLowerCase(), alias);
      }
    }
    for (const alias of record.aliases) {
      const trimmed = alias.trim();
      if (!trimmed) {
        continue;
      }
      aliasSet.set(trimmed.toLowerCase(), trimmed);
    }
    const mergedAliases = Array.from(aliasSet.values()).sort((a, b) => a.localeCompare(b));
    const normalizedAliasList = mergedAliases.length ? mergedAliases : undefined;
    const existingAliasList = (current.aliases ?? []).slice().sort((a, b) => a.localeCompare(b));
    const nextRecord: IsoCodeRecord = {
      ...current,
      countryName: record.countryName,
      countryAlpha2: key,
      currencyAlpha3: current.currencyAlpha3 ?? "",
      aliases: normalizedAliasList
    };

    if (
      nextRecord.countryName !== current.countryName ||
      !arraysEqual(normalizedAliasList ?? [], existingAliasList)
    ) {
      updated += 1;
    }

    mergedMap.set(key, nextRecord);
  }

  const mergedRecords = Array.from(mergedMap.values()).sort((a, b) => a.countryName.localeCompare(b.countryName));
  await fs.writeJson(catalogPath, mergedRecords, { spaces: 2 });
  reloadIsoCountryCatalog(mergedRecords);

  return {
    downloaded: payload.length,
    normalized: normalized.length,
    added,
    updated,
    skipped: payload.length - normalized.length,
    catalogPath
  };
}

async function readExistingCatalog(catalogPath: string): Promise<IsoCodeRecord[]> {
  try {
    const data = await fs.readJson(catalogPath);
    return Array.isArray(data) ? (data as IsoCodeRecord[]) : [];
  } catch {
    return [];
  }
}

function normalizeSourceRecord(record: SourceCountryRecord): NormalizedCountryRecord | null {
  const name = record.name?.trim();
  const iso2 = record["alpha-2"]?.trim();
  if (!name || !iso2) {
    return null;
  }
  const asciiName = toAscii(name);
  const aliases: string[] = [];
  const officialName = record["official_name_en"] ?? record["official_name"];
  if (officialName && officialName.trim() && officialName.trim() !== name) {
    aliases.push(toAscii(officialName.trim()));
  }
  const alpha3 = record["alpha-3"]?.trim();
  if (alpha3) {
    aliases.push(alpha3.toUpperCase());
  }
  return {
    countryName: asciiName,
    countryAlpha2: iso2.toUpperCase(),
    aliases: dedupeAliases(aliases).sort((a, b) => a.localeCompare(b))
  };
}

function toAscii(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^ -]/g, "")
    .trim();
}

function dedupeAliases(values: string[]): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const value of values) {
    const normalized = value.trim();
    if (!normalized) {
      continue;
    }
    const key = normalized.toLowerCase();
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    result.push(normalized);
  }
  return result;
}

function arraysEqual(a: string[], b: string[]): boolean {
  if (a.length !== b.length) {
    return false;
  }
  return a.every((value, index) => value === b[index]);
}
